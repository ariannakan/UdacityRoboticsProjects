^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtlebot_dashboard
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.3.1 (2015-03-23)
------------------

2.3.0 (2014-12-30)
------------------

2.2.2 (2013-10-25)
------------------
* Unchanged release

2.2.0 (2013-08-30)
------------------
* Add bugtracker and repo info URLs.
* Rename launcher includes to xyz.launch.xml.
* Changelogs at package level.


2.1.x - hydro, unstable
=======================

2.1.1 (2013-07-23)
------------------

2.1.0 (2013-07-16)
------------------
* Catkinized


Previous versions, bugfixing
============================

Available in ROS wiki: http://ros.org/wiki/turtlebot_viz/ChangeList
